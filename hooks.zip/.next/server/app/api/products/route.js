/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/products/route";
exports.ids = ["app/api/products/route"];
exports.modules = {

/***/ "(rsc)/./app/api/products/route.ts":
/*!***********************************!*\
  !*** ./app/api/products/route.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   GET: () => (/* binding */ GET)\n/* harmony export */ });\n/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\n/* harmony import */ var _lib_supabase_server__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/lib/supabase/server */ \"(rsc)/./lib/supabase/server.ts\");\n\n\n// Fallback data in case database is not set up\nconst fallbackProducts = [\n    {\n        id: 1,\n        name: \"Standard Kraft Paper Bag\",\n        category: \"retail\",\n        price: 0.45,\n        size: \"medium\",\n        material: \"kraft\",\n        image_url: \"/placeholder.svg?height=300&width=300\",\n        description: \"Durable kraft paper bag with twisted paper handles. Perfect for retail stores.\",\n        sku: \"SKU-001\",\n        stock_quantity: 100,\n        is_featured: true,\n        created_at: new Date().toISOString(),\n        updated_at: new Date().toISOString()\n    },\n    {\n        id: 2,\n        name: \"White Paper Bag with Flat Handles\",\n        category: \"retail\",\n        price: 0.55,\n        size: \"large\",\n        material: \"white\",\n        image_url: \"/placeholder.svg?height=300&width=300\",\n        description: \"Elegant white paper bag with flat handles, ideal for clothing and accessories.\",\n        sku: \"SKU-002\",\n        stock_quantity: 75,\n        is_featured: false,\n        created_at: new Date().toISOString(),\n        updated_at: new Date().toISOString()\n    },\n    {\n        id: 3,\n        name: \"Food Delivery Bag\",\n        category: \"food\",\n        price: 0.35,\n        size: \"small\",\n        material: \"kraft\",\n        image_url: \"/placeholder.svg?height=300&width=300\",\n        description: \"Grease-resistant paper bag designed for takeaway food items.\",\n        sku: \"SKU-003\",\n        stock_quantity: 200,\n        is_featured: true,\n        created_at: new Date().toISOString(),\n        updated_at: new Date().toISOString()\n    },\n    {\n        id: 4,\n        name: \"Luxury Boutique Bag\",\n        category: \"luxury\",\n        price: 0.95,\n        size: \"medium\",\n        material: \"premium\",\n        image_url: \"/placeholder.svg?height=300&width=300\",\n        description: \"Premium quality paper bag with ribbon handles and gold foil printing.\",\n        sku: \"SKU-004\",\n        stock_quantity: 50,\n        is_featured: true,\n        created_at: new Date().toISOString(),\n        updated_at: new Date().toISOString()\n    },\n    {\n        id: 5,\n        name: \"Bakery Paper Bag\",\n        category: \"food\",\n        price: 0.25,\n        size: \"small\",\n        material: \"kraft\",\n        image_url: \"/placeholder.svg?height=300&width=300\",\n        description: \"Food-safe paper bag perfect for bakery items and pastries.\",\n        sku: \"SKU-005\",\n        stock_quantity: 150,\n        is_featured: false,\n        created_at: new Date().toISOString(),\n        updated_at: new Date().toISOString()\n    },\n    {\n        id: 6,\n        name: \"Gift Bag with Rope Handles\",\n        category: \"luxury\",\n        price: 0.85,\n        size: \"medium\",\n        material: \"premium\",\n        image_url: \"/placeholder.svg?height=300&width=300\",\n        description: \"Elegant gift bag with rope handles and matte finish.\",\n        sku: \"SKU-006\",\n        stock_quantity: 60,\n        is_featured: false,\n        created_at: new Date().toISOString(),\n        updated_at: new Date().toISOString()\n    },\n    {\n        id: 7,\n        name: \"Grocery Paper Bag\",\n        category: \"retail\",\n        price: 0.65,\n        size: \"large\",\n        material: \"kraft\",\n        image_url: \"/placeholder.svg?height=300&width=300\",\n        description: \"Strong kraft paper bag with reinforced bottom, ideal for groceries.\",\n        sku: \"SKU-007\",\n        stock_quantity: 120,\n        is_featured: false,\n        created_at: new Date().toISOString(),\n        updated_at: new Date().toISOString()\n    },\n    {\n        id: 8,\n        name: \"Pharmacy Paper Bag\",\n        category: \"retail\",\n        price: 0.4,\n        size: \"small\",\n        material: \"white\",\n        image_url: \"/placeholder.svg?height=300&width=300\",\n        description: \"Clean white paper bag suitable for pharmacies and healthcare products.\",\n        sku: \"SKU-008\",\n        stock_quantity: 90,\n        is_featured: false,\n        created_at: new Date().toISOString(),\n        updated_at: new Date().toISOString()\n    },\n    {\n        id: 9,\n        name: \"Wine Bottle Bag\",\n        category: \"luxury\",\n        price: 0.75,\n        size: \"medium\",\n        material: \"premium\",\n        image_url: \"/placeholder.svg?height=300&width=300\",\n        description: \"Specialized paper bag designed to hold wine bottles securely.\",\n        sku: \"SKU-009\",\n        stock_quantity: 40,\n        is_featured: false,\n        created_at: new Date().toISOString(),\n        updated_at: new Date().toISOString()\n    },\n    {\n        id: 10,\n        name: \"Custom Printed Bag\",\n        category: \"retail\",\n        price: 0.85,\n        size: \"large\",\n        material: \"kraft\",\n        image_url: \"/placeholder.svg?height=300&width=300\",\n        description: \"Customizable kraft paper bag with your logo and branding.\",\n        sku: \"SKU-010\",\n        stock_quantity: 80,\n        is_featured: true,\n        created_at: new Date().toISOString(),\n        updated_at: new Date().toISOString()\n    }\n];\nfunction applyFilters(products, searchParams) {\n    let filteredProducts = [\n        ...products\n    ];\n    const category = searchParams.get(\"category\");\n    const featured = searchParams.get(\"featured\");\n    const limit = searchParams.get(\"limit\");\n    if (category) {\n        filteredProducts = filteredProducts.filter((p)=>p.category === category);\n    }\n    if (featured === \"true\") {\n        filteredProducts = filteredProducts.filter((p)=>p.is_featured);\n    }\n    if (limit) {\n        filteredProducts = filteredProducts.slice(0, Number.parseInt(limit));\n    }\n    return filteredProducts;\n}\nasync function GET(request) {\n    const { searchParams } = new URL(request.url);\n    try {\n        // Try to connect to Supabase\n        const supabase = await (0,_lib_supabase_server__WEBPACK_IMPORTED_MODULE_1__.createClient)();\n        let query = supabase.from(\"products\").select(\"*\").order(\"created_at\", {\n            ascending: false\n        });\n        const category = searchParams.get(\"category\");\n        const featured = searchParams.get(\"featured\");\n        const limit = searchParams.get(\"limit\");\n        if (category) {\n            query = query.eq(\"category\", category);\n        }\n        if (featured === \"true\") {\n            query = query.eq(\"is_featured\", true);\n        }\n        if (limit) {\n            query = query.limit(Number.parseInt(limit));\n        }\n        const { data: products, error } = await query;\n        if (error) {\n            console.log(\"Database error, using fallback data:\", error.message);\n            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json(applyFilters(fallbackProducts, searchParams));\n        }\n        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json(products || []);\n    } catch (error) {\n        console.log(\"Connection error, using fallback data:\", error);\n        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json(applyFilters(fallbackProducts, searchParams));\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvYXBpL3Byb2R1Y3RzL3JvdXRlLnRzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUE0RDtBQUNSO0FBRXBELCtDQUErQztBQUMvQyxNQUFNRSxtQkFBbUI7SUFDdkI7UUFDRUMsSUFBSTtRQUNKQyxNQUFNO1FBQ05DLFVBQVU7UUFDVkMsT0FBTztRQUNQQyxNQUFNO1FBQ05DLFVBQVU7UUFDVkMsV0FBVztRQUNYQyxhQUFhO1FBQ2JDLEtBQUs7UUFDTEMsZ0JBQWdCO1FBQ2hCQyxhQUFhO1FBQ2JDLFlBQVksSUFBSUMsT0FBT0MsV0FBVztRQUNsQ0MsWUFBWSxJQUFJRixPQUFPQyxXQUFXO0lBQ3BDO0lBQ0E7UUFDRWIsSUFBSTtRQUNKQyxNQUFNO1FBQ05DLFVBQVU7UUFDVkMsT0FBTztRQUNQQyxNQUFNO1FBQ05DLFVBQVU7UUFDVkMsV0FBVztRQUNYQyxhQUFhO1FBQ2JDLEtBQUs7UUFDTEMsZ0JBQWdCO1FBQ2hCQyxhQUFhO1FBQ2JDLFlBQVksSUFBSUMsT0FBT0MsV0FBVztRQUNsQ0MsWUFBWSxJQUFJRixPQUFPQyxXQUFXO0lBQ3BDO0lBQ0E7UUFDRWIsSUFBSTtRQUNKQyxNQUFNO1FBQ05DLFVBQVU7UUFDVkMsT0FBTztRQUNQQyxNQUFNO1FBQ05DLFVBQVU7UUFDVkMsV0FBVztRQUNYQyxhQUFhO1FBQ2JDLEtBQUs7UUFDTEMsZ0JBQWdCO1FBQ2hCQyxhQUFhO1FBQ2JDLFlBQVksSUFBSUMsT0FBT0MsV0FBVztRQUNsQ0MsWUFBWSxJQUFJRixPQUFPQyxXQUFXO0lBQ3BDO0lBQ0E7UUFDRWIsSUFBSTtRQUNKQyxNQUFNO1FBQ05DLFVBQVU7UUFDVkMsT0FBTztRQUNQQyxNQUFNO1FBQ05DLFVBQVU7UUFDVkMsV0FBVztRQUNYQyxhQUFhO1FBQ2JDLEtBQUs7UUFDTEMsZ0JBQWdCO1FBQ2hCQyxhQUFhO1FBQ2JDLFlBQVksSUFBSUMsT0FBT0MsV0FBVztRQUNsQ0MsWUFBWSxJQUFJRixPQUFPQyxXQUFXO0lBQ3BDO0lBQ0E7UUFDRWIsSUFBSTtRQUNKQyxNQUFNO1FBQ05DLFVBQVU7UUFDVkMsT0FBTztRQUNQQyxNQUFNO1FBQ05DLFVBQVU7UUFDVkMsV0FBVztRQUNYQyxhQUFhO1FBQ2JDLEtBQUs7UUFDTEMsZ0JBQWdCO1FBQ2hCQyxhQUFhO1FBQ2JDLFlBQVksSUFBSUMsT0FBT0MsV0FBVztRQUNsQ0MsWUFBWSxJQUFJRixPQUFPQyxXQUFXO0lBQ3BDO0lBQ0E7UUFDRWIsSUFBSTtRQUNKQyxNQUFNO1FBQ05DLFVBQVU7UUFDVkMsT0FBTztRQUNQQyxNQUFNO1FBQ05DLFVBQVU7UUFDVkMsV0FBVztRQUNYQyxhQUFhO1FBQ2JDLEtBQUs7UUFDTEMsZ0JBQWdCO1FBQ2hCQyxhQUFhO1FBQ2JDLFlBQVksSUFBSUMsT0FBT0MsV0FBVztRQUNsQ0MsWUFBWSxJQUFJRixPQUFPQyxXQUFXO0lBQ3BDO0lBQ0E7UUFDRWIsSUFBSTtRQUNKQyxNQUFNO1FBQ05DLFVBQVU7UUFDVkMsT0FBTztRQUNQQyxNQUFNO1FBQ05DLFVBQVU7UUFDVkMsV0FBVztRQUNYQyxhQUFhO1FBQ2JDLEtBQUs7UUFDTEMsZ0JBQWdCO1FBQ2hCQyxhQUFhO1FBQ2JDLFlBQVksSUFBSUMsT0FBT0MsV0FBVztRQUNsQ0MsWUFBWSxJQUFJRixPQUFPQyxXQUFXO0lBQ3BDO0lBQ0E7UUFDRWIsSUFBSTtRQUNKQyxNQUFNO1FBQ05DLFVBQVU7UUFDVkMsT0FBTztRQUNQQyxNQUFNO1FBQ05DLFVBQVU7UUFDVkMsV0FBVztRQUNYQyxhQUFhO1FBQ2JDLEtBQUs7UUFDTEMsZ0JBQWdCO1FBQ2hCQyxhQUFhO1FBQ2JDLFlBQVksSUFBSUMsT0FBT0MsV0FBVztRQUNsQ0MsWUFBWSxJQUFJRixPQUFPQyxXQUFXO0lBQ3BDO0lBQ0E7UUFDRWIsSUFBSTtRQUNKQyxNQUFNO1FBQ05DLFVBQVU7UUFDVkMsT0FBTztRQUNQQyxNQUFNO1FBQ05DLFVBQVU7UUFDVkMsV0FBVztRQUNYQyxhQUFhO1FBQ2JDLEtBQUs7UUFDTEMsZ0JBQWdCO1FBQ2hCQyxhQUFhO1FBQ2JDLFlBQVksSUFBSUMsT0FBT0MsV0FBVztRQUNsQ0MsWUFBWSxJQUFJRixPQUFPQyxXQUFXO0lBQ3BDO0lBQ0E7UUFDRWIsSUFBSTtRQUNKQyxNQUFNO1FBQ05DLFVBQVU7UUFDVkMsT0FBTztRQUNQQyxNQUFNO1FBQ05DLFVBQVU7UUFDVkMsV0FBVztRQUNYQyxhQUFhO1FBQ2JDLEtBQUs7UUFDTEMsZ0JBQWdCO1FBQ2hCQyxhQUFhO1FBQ2JDLFlBQVksSUFBSUMsT0FBT0MsV0FBVztRQUNsQ0MsWUFBWSxJQUFJRixPQUFPQyxXQUFXO0lBQ3BDO0NBQ0Q7QUFFRCxTQUFTRSxhQUFhQyxRQUFpQyxFQUFFQyxZQUE2QjtJQUNwRixJQUFJQyxtQkFBbUI7V0FBSUY7S0FBUztJQUVwQyxNQUFNZCxXQUFXZSxhQUFhRSxHQUFHLENBQUM7SUFDbEMsTUFBTUMsV0FBV0gsYUFBYUUsR0FBRyxDQUFDO0lBQ2xDLE1BQU1FLFFBQVFKLGFBQWFFLEdBQUcsQ0FBQztJQUUvQixJQUFJakIsVUFBVTtRQUNaZ0IsbUJBQW1CQSxpQkFBaUJJLE1BQU0sQ0FBQyxDQUFDQyxJQUFNQSxFQUFFckIsUUFBUSxLQUFLQTtJQUNuRTtJQUVBLElBQUlrQixhQUFhLFFBQVE7UUFDdkJGLG1CQUFtQkEsaUJBQWlCSSxNQUFNLENBQUMsQ0FBQ0MsSUFBTUEsRUFBRWIsV0FBVztJQUNqRTtJQUVBLElBQUlXLE9BQU87UUFDVEgsbUJBQW1CQSxpQkFBaUJNLEtBQUssQ0FBQyxHQUFHQyxPQUFPQyxRQUFRLENBQUNMO0lBQy9EO0lBRUEsT0FBT0g7QUFDVDtBQUVPLGVBQWVTLElBQUlDLE9BQW9CO0lBQzVDLE1BQU0sRUFBRVgsWUFBWSxFQUFFLEdBQUcsSUFBSVksSUFBSUQsUUFBUUUsR0FBRztJQUU1QyxJQUFJO1FBQ0YsNkJBQTZCO1FBQzdCLE1BQU1DLFdBQVcsTUFBTWpDLGtFQUFZQTtRQUVuQyxJQUFJa0MsUUFBUUQsU0FBU0UsSUFBSSxDQUFDLFlBQVlDLE1BQU0sQ0FBQyxLQUFLQyxLQUFLLENBQUMsY0FBYztZQUFFQyxXQUFXO1FBQU07UUFFekYsTUFBTWxDLFdBQVdlLGFBQWFFLEdBQUcsQ0FBQztRQUNsQyxNQUFNQyxXQUFXSCxhQUFhRSxHQUFHLENBQUM7UUFDbEMsTUFBTUUsUUFBUUosYUFBYUUsR0FBRyxDQUFDO1FBRS9CLElBQUlqQixVQUFVO1lBQ1o4QixRQUFRQSxNQUFNSyxFQUFFLENBQUMsWUFBWW5DO1FBQy9CO1FBRUEsSUFBSWtCLGFBQWEsUUFBUTtZQUN2QlksUUFBUUEsTUFBTUssRUFBRSxDQUFDLGVBQWU7UUFDbEM7UUFFQSxJQUFJaEIsT0FBTztZQUNUVyxRQUFRQSxNQUFNWCxLQUFLLENBQUNJLE9BQU9DLFFBQVEsQ0FBQ0w7UUFDdEM7UUFFQSxNQUFNLEVBQUVpQixNQUFNdEIsUUFBUSxFQUFFdUIsS0FBSyxFQUFFLEdBQUcsTUFBTVA7UUFFeEMsSUFBSU8sT0FBTztZQUNUQyxRQUFRQyxHQUFHLENBQUMsd0NBQXdDRixNQUFNRyxPQUFPO1lBQ2pFLE9BQU83QyxxREFBWUEsQ0FBQzhDLElBQUksQ0FBQzVCLGFBQWFoQixrQkFBa0JrQjtRQUMxRDtRQUVBLE9BQU9wQixxREFBWUEsQ0FBQzhDLElBQUksQ0FBQzNCLFlBQVksRUFBRTtJQUN6QyxFQUFFLE9BQU91QixPQUFPO1FBQ2RDLFFBQVFDLEdBQUcsQ0FBQywwQ0FBMENGO1FBQ3RELE9BQU8xQyxxREFBWUEsQ0FBQzhDLElBQUksQ0FBQzVCLGFBQWFoQixrQkFBa0JrQjtJQUMxRDtBQUNGIiwic291cmNlcyI6WyJDOlxcVXNlcnNcXFRhbGhhXFxEb3dubG9hZHNcXHRyZW50ZWNvLXdlYnNpdGV2M1xcYXBwXFxhcGlcXHByb2R1Y3RzXFxyb3V0ZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB0eXBlIE5leHRSZXF1ZXN0LCBOZXh0UmVzcG9uc2UgfSBmcm9tIFwibmV4dC9zZXJ2ZXJcIlxuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcIkAvbGliL3N1cGFiYXNlL3NlcnZlclwiXG5cbi8vIEZhbGxiYWNrIGRhdGEgaW4gY2FzZSBkYXRhYmFzZSBpcyBub3Qgc2V0IHVwXG5jb25zdCBmYWxsYmFja1Byb2R1Y3RzID0gW1xuICB7XG4gICAgaWQ6IDEsXG4gICAgbmFtZTogXCJTdGFuZGFyZCBLcmFmdCBQYXBlciBCYWdcIixcbiAgICBjYXRlZ29yeTogXCJyZXRhaWxcIixcbiAgICBwcmljZTogMC40NSxcbiAgICBzaXplOiBcIm1lZGl1bVwiLFxuICAgIG1hdGVyaWFsOiBcImtyYWZ0XCIsXG4gICAgaW1hZ2VfdXJsOiBcIi9wbGFjZWhvbGRlci5zdmc/aGVpZ2h0PTMwMCZ3aWR0aD0zMDBcIixcbiAgICBkZXNjcmlwdGlvbjogXCJEdXJhYmxlIGtyYWZ0IHBhcGVyIGJhZyB3aXRoIHR3aXN0ZWQgcGFwZXIgaGFuZGxlcy4gUGVyZmVjdCBmb3IgcmV0YWlsIHN0b3Jlcy5cIixcbiAgICBza3U6IFwiU0tVLTAwMVwiLFxuICAgIHN0b2NrX3F1YW50aXR5OiAxMDAsXG4gICAgaXNfZmVhdHVyZWQ6IHRydWUsXG4gICAgY3JlYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgfSxcbiAge1xuICAgIGlkOiAyLFxuICAgIG5hbWU6IFwiV2hpdGUgUGFwZXIgQmFnIHdpdGggRmxhdCBIYW5kbGVzXCIsXG4gICAgY2F0ZWdvcnk6IFwicmV0YWlsXCIsXG4gICAgcHJpY2U6IDAuNTUsXG4gICAgc2l6ZTogXCJsYXJnZVwiLFxuICAgIG1hdGVyaWFsOiBcIndoaXRlXCIsXG4gICAgaW1hZ2VfdXJsOiBcIi9wbGFjZWhvbGRlci5zdmc/aGVpZ2h0PTMwMCZ3aWR0aD0zMDBcIixcbiAgICBkZXNjcmlwdGlvbjogXCJFbGVnYW50IHdoaXRlIHBhcGVyIGJhZyB3aXRoIGZsYXQgaGFuZGxlcywgaWRlYWwgZm9yIGNsb3RoaW5nIGFuZCBhY2Nlc3Nvcmllcy5cIixcbiAgICBza3U6IFwiU0tVLTAwMlwiLFxuICAgIHN0b2NrX3F1YW50aXR5OiA3NSxcbiAgICBpc19mZWF0dXJlZDogZmFsc2UsXG4gICAgY3JlYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgfSxcbiAge1xuICAgIGlkOiAzLFxuICAgIG5hbWU6IFwiRm9vZCBEZWxpdmVyeSBCYWdcIixcbiAgICBjYXRlZ29yeTogXCJmb29kXCIsXG4gICAgcHJpY2U6IDAuMzUsXG4gICAgc2l6ZTogXCJzbWFsbFwiLFxuICAgIG1hdGVyaWFsOiBcImtyYWZ0XCIsXG4gICAgaW1hZ2VfdXJsOiBcIi9wbGFjZWhvbGRlci5zdmc/aGVpZ2h0PTMwMCZ3aWR0aD0zMDBcIixcbiAgICBkZXNjcmlwdGlvbjogXCJHcmVhc2UtcmVzaXN0YW50IHBhcGVyIGJhZyBkZXNpZ25lZCBmb3IgdGFrZWF3YXkgZm9vZCBpdGVtcy5cIixcbiAgICBza3U6IFwiU0tVLTAwM1wiLFxuICAgIHN0b2NrX3F1YW50aXR5OiAyMDAsXG4gICAgaXNfZmVhdHVyZWQ6IHRydWUsXG4gICAgY3JlYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgfSxcbiAge1xuICAgIGlkOiA0LFxuICAgIG5hbWU6IFwiTHV4dXJ5IEJvdXRpcXVlIEJhZ1wiLFxuICAgIGNhdGVnb3J5OiBcImx1eHVyeVwiLFxuICAgIHByaWNlOiAwLjk1LFxuICAgIHNpemU6IFwibWVkaXVtXCIsXG4gICAgbWF0ZXJpYWw6IFwicHJlbWl1bVwiLFxuICAgIGltYWdlX3VybDogXCIvcGxhY2Vob2xkZXIuc3ZnP2hlaWdodD0zMDAmd2lkdGg9MzAwXCIsXG4gICAgZGVzY3JpcHRpb246IFwiUHJlbWl1bSBxdWFsaXR5IHBhcGVyIGJhZyB3aXRoIHJpYmJvbiBoYW5kbGVzIGFuZCBnb2xkIGZvaWwgcHJpbnRpbmcuXCIsXG4gICAgc2t1OiBcIlNLVS0wMDRcIixcbiAgICBzdG9ja19xdWFudGl0eTogNTAsXG4gICAgaXNfZmVhdHVyZWQ6IHRydWUsXG4gICAgY3JlYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgfSxcbiAge1xuICAgIGlkOiA1LFxuICAgIG5hbWU6IFwiQmFrZXJ5IFBhcGVyIEJhZ1wiLFxuICAgIGNhdGVnb3J5OiBcImZvb2RcIixcbiAgICBwcmljZTogMC4yNSxcbiAgICBzaXplOiBcInNtYWxsXCIsXG4gICAgbWF0ZXJpYWw6IFwia3JhZnRcIixcbiAgICBpbWFnZV91cmw6IFwiL3BsYWNlaG9sZGVyLnN2Zz9oZWlnaHQ9MzAwJndpZHRoPTMwMFwiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkZvb2Qtc2FmZSBwYXBlciBiYWcgcGVyZmVjdCBmb3IgYmFrZXJ5IGl0ZW1zIGFuZCBwYXN0cmllcy5cIixcbiAgICBza3U6IFwiU0tVLTAwNVwiLFxuICAgIHN0b2NrX3F1YW50aXR5OiAxNTAsXG4gICAgaXNfZmVhdHVyZWQ6IGZhbHNlLFxuICAgIGNyZWF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gIH0sXG4gIHtcbiAgICBpZDogNixcbiAgICBuYW1lOiBcIkdpZnQgQmFnIHdpdGggUm9wZSBIYW5kbGVzXCIsXG4gICAgY2F0ZWdvcnk6IFwibHV4dXJ5XCIsXG4gICAgcHJpY2U6IDAuODUsXG4gICAgc2l6ZTogXCJtZWRpdW1cIixcbiAgICBtYXRlcmlhbDogXCJwcmVtaXVtXCIsXG4gICAgaW1hZ2VfdXJsOiBcIi9wbGFjZWhvbGRlci5zdmc/aGVpZ2h0PTMwMCZ3aWR0aD0zMDBcIixcbiAgICBkZXNjcmlwdGlvbjogXCJFbGVnYW50IGdpZnQgYmFnIHdpdGggcm9wZSBoYW5kbGVzIGFuZCBtYXR0ZSBmaW5pc2guXCIsXG4gICAgc2t1OiBcIlNLVS0wMDZcIixcbiAgICBzdG9ja19xdWFudGl0eTogNjAsXG4gICAgaXNfZmVhdHVyZWQ6IGZhbHNlLFxuICAgIGNyZWF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gIH0sXG4gIHtcbiAgICBpZDogNyxcbiAgICBuYW1lOiBcIkdyb2NlcnkgUGFwZXIgQmFnXCIsXG4gICAgY2F0ZWdvcnk6IFwicmV0YWlsXCIsXG4gICAgcHJpY2U6IDAuNjUsXG4gICAgc2l6ZTogXCJsYXJnZVwiLFxuICAgIG1hdGVyaWFsOiBcImtyYWZ0XCIsXG4gICAgaW1hZ2VfdXJsOiBcIi9wbGFjZWhvbGRlci5zdmc/aGVpZ2h0PTMwMCZ3aWR0aD0zMDBcIixcbiAgICBkZXNjcmlwdGlvbjogXCJTdHJvbmcga3JhZnQgcGFwZXIgYmFnIHdpdGggcmVpbmZvcmNlZCBib3R0b20sIGlkZWFsIGZvciBncm9jZXJpZXMuXCIsXG4gICAgc2t1OiBcIlNLVS0wMDdcIixcbiAgICBzdG9ja19xdWFudGl0eTogMTIwLFxuICAgIGlzX2ZlYXR1cmVkOiBmYWxzZSxcbiAgICBjcmVhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICB9LFxuICB7XG4gICAgaWQ6IDgsXG4gICAgbmFtZTogXCJQaGFybWFjeSBQYXBlciBCYWdcIixcbiAgICBjYXRlZ29yeTogXCJyZXRhaWxcIixcbiAgICBwcmljZTogMC40LFxuICAgIHNpemU6IFwic21hbGxcIixcbiAgICBtYXRlcmlhbDogXCJ3aGl0ZVwiLFxuICAgIGltYWdlX3VybDogXCIvcGxhY2Vob2xkZXIuc3ZnP2hlaWdodD0zMDAmd2lkdGg9MzAwXCIsXG4gICAgZGVzY3JpcHRpb246IFwiQ2xlYW4gd2hpdGUgcGFwZXIgYmFnIHN1aXRhYmxlIGZvciBwaGFybWFjaWVzIGFuZCBoZWFsdGhjYXJlIHByb2R1Y3RzLlwiLFxuICAgIHNrdTogXCJTS1UtMDA4XCIsXG4gICAgc3RvY2tfcXVhbnRpdHk6IDkwLFxuICAgIGlzX2ZlYXR1cmVkOiBmYWxzZSxcbiAgICBjcmVhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICB9LFxuICB7XG4gICAgaWQ6IDksXG4gICAgbmFtZTogXCJXaW5lIEJvdHRsZSBCYWdcIixcbiAgICBjYXRlZ29yeTogXCJsdXh1cnlcIixcbiAgICBwcmljZTogMC43NSxcbiAgICBzaXplOiBcIm1lZGl1bVwiLFxuICAgIG1hdGVyaWFsOiBcInByZW1pdW1cIixcbiAgICBpbWFnZV91cmw6IFwiL3BsYWNlaG9sZGVyLnN2Zz9oZWlnaHQ9MzAwJndpZHRoPTMwMFwiLFxuICAgIGRlc2NyaXB0aW9uOiBcIlNwZWNpYWxpemVkIHBhcGVyIGJhZyBkZXNpZ25lZCB0byBob2xkIHdpbmUgYm90dGxlcyBzZWN1cmVseS5cIixcbiAgICBza3U6IFwiU0tVLTAwOVwiLFxuICAgIHN0b2NrX3F1YW50aXR5OiA0MCxcbiAgICBpc19mZWF0dXJlZDogZmFsc2UsXG4gICAgY3JlYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgfSxcbiAge1xuICAgIGlkOiAxMCxcbiAgICBuYW1lOiBcIkN1c3RvbSBQcmludGVkIEJhZ1wiLFxuICAgIGNhdGVnb3J5OiBcInJldGFpbFwiLFxuICAgIHByaWNlOiAwLjg1LFxuICAgIHNpemU6IFwibGFyZ2VcIixcbiAgICBtYXRlcmlhbDogXCJrcmFmdFwiLFxuICAgIGltYWdlX3VybDogXCIvcGxhY2Vob2xkZXIuc3ZnP2hlaWdodD0zMDAmd2lkdGg9MzAwXCIsXG4gICAgZGVzY3JpcHRpb246IFwiQ3VzdG9taXphYmxlIGtyYWZ0IHBhcGVyIGJhZyB3aXRoIHlvdXIgbG9nbyBhbmQgYnJhbmRpbmcuXCIsXG4gICAgc2t1OiBcIlNLVS0wMTBcIixcbiAgICBzdG9ja19xdWFudGl0eTogODAsXG4gICAgaXNfZmVhdHVyZWQ6IHRydWUsXG4gICAgY3JlYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgfSxcbl1cblxuZnVuY3Rpb24gYXBwbHlGaWx0ZXJzKHByb2R1Y3RzOiB0eXBlb2YgZmFsbGJhY2tQcm9kdWN0cywgc2VhcmNoUGFyYW1zOiBVUkxTZWFyY2hQYXJhbXMpIHtcbiAgbGV0IGZpbHRlcmVkUHJvZHVjdHMgPSBbLi4ucHJvZHVjdHNdXG5cbiAgY29uc3QgY2F0ZWdvcnkgPSBzZWFyY2hQYXJhbXMuZ2V0KFwiY2F0ZWdvcnlcIilcbiAgY29uc3QgZmVhdHVyZWQgPSBzZWFyY2hQYXJhbXMuZ2V0KFwiZmVhdHVyZWRcIilcbiAgY29uc3QgbGltaXQgPSBzZWFyY2hQYXJhbXMuZ2V0KFwibGltaXRcIilcblxuICBpZiAoY2F0ZWdvcnkpIHtcbiAgICBmaWx0ZXJlZFByb2R1Y3RzID0gZmlsdGVyZWRQcm9kdWN0cy5maWx0ZXIoKHApID0+IHAuY2F0ZWdvcnkgPT09IGNhdGVnb3J5KVxuICB9XG5cbiAgaWYgKGZlYXR1cmVkID09PSBcInRydWVcIikge1xuICAgIGZpbHRlcmVkUHJvZHVjdHMgPSBmaWx0ZXJlZFByb2R1Y3RzLmZpbHRlcigocCkgPT4gcC5pc19mZWF0dXJlZClcbiAgfVxuXG4gIGlmIChsaW1pdCkge1xuICAgIGZpbHRlcmVkUHJvZHVjdHMgPSBmaWx0ZXJlZFByb2R1Y3RzLnNsaWNlKDAsIE51bWJlci5wYXJzZUludChsaW1pdCkpXG4gIH1cblxuICByZXR1cm4gZmlsdGVyZWRQcm9kdWN0c1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gR0VUKHJlcXVlc3Q6IE5leHRSZXF1ZXN0KSB7XG4gIGNvbnN0IHsgc2VhcmNoUGFyYW1zIH0gPSBuZXcgVVJMKHJlcXVlc3QudXJsKVxuXG4gIHRyeSB7XG4gICAgLy8gVHJ5IHRvIGNvbm5lY3QgdG8gU3VwYWJhc2VcbiAgICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpXG5cbiAgICBsZXQgcXVlcnkgPSBzdXBhYmFzZS5mcm9tKFwicHJvZHVjdHNcIikuc2VsZWN0KFwiKlwiKS5vcmRlcihcImNyZWF0ZWRfYXRcIiwgeyBhc2NlbmRpbmc6IGZhbHNlIH0pXG5cbiAgICBjb25zdCBjYXRlZ29yeSA9IHNlYXJjaFBhcmFtcy5nZXQoXCJjYXRlZ29yeVwiKVxuICAgIGNvbnN0IGZlYXR1cmVkID0gc2VhcmNoUGFyYW1zLmdldChcImZlYXR1cmVkXCIpXG4gICAgY29uc3QgbGltaXQgPSBzZWFyY2hQYXJhbXMuZ2V0KFwibGltaXRcIilcblxuICAgIGlmIChjYXRlZ29yeSkge1xuICAgICAgcXVlcnkgPSBxdWVyeS5lcShcImNhdGVnb3J5XCIsIGNhdGVnb3J5KVxuICAgIH1cblxuICAgIGlmIChmZWF0dXJlZCA9PT0gXCJ0cnVlXCIpIHtcbiAgICAgIHF1ZXJ5ID0gcXVlcnkuZXEoXCJpc19mZWF0dXJlZFwiLCB0cnVlKVxuICAgIH1cblxuICAgIGlmIChsaW1pdCkge1xuICAgICAgcXVlcnkgPSBxdWVyeS5saW1pdChOdW1iZXIucGFyc2VJbnQobGltaXQpKVxuICAgIH1cblxuICAgIGNvbnN0IHsgZGF0YTogcHJvZHVjdHMsIGVycm9yIH0gPSBhd2FpdCBxdWVyeVxuXG4gICAgaWYgKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmxvZyhcIkRhdGFiYXNlIGVycm9yLCB1c2luZyBmYWxsYmFjayBkYXRhOlwiLCBlcnJvci5tZXNzYWdlKVxuICAgICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKGFwcGx5RmlsdGVycyhmYWxsYmFja1Byb2R1Y3RzLCBzZWFyY2hQYXJhbXMpKVxuICAgIH1cblxuICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbihwcm9kdWN0cyB8fCBbXSlcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmxvZyhcIkNvbm5lY3Rpb24gZXJyb3IsIHVzaW5nIGZhbGxiYWNrIGRhdGE6XCIsIGVycm9yKVxuICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbihhcHBseUZpbHRlcnMoZmFsbGJhY2tQcm9kdWN0cywgc2VhcmNoUGFyYW1zKSlcbiAgfVxufVxuIl0sIm5hbWVzIjpbIk5leHRSZXNwb25zZSIsImNyZWF0ZUNsaWVudCIsImZhbGxiYWNrUHJvZHVjdHMiLCJpZCIsIm5hbWUiLCJjYXRlZ29yeSIsInByaWNlIiwic2l6ZSIsIm1hdGVyaWFsIiwiaW1hZ2VfdXJsIiwiZGVzY3JpcHRpb24iLCJza3UiLCJzdG9ja19xdWFudGl0eSIsImlzX2ZlYXR1cmVkIiwiY3JlYXRlZF9hdCIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInVwZGF0ZWRfYXQiLCJhcHBseUZpbHRlcnMiLCJwcm9kdWN0cyIsInNlYXJjaFBhcmFtcyIsImZpbHRlcmVkUHJvZHVjdHMiLCJnZXQiLCJmZWF0dXJlZCIsImxpbWl0IiwiZmlsdGVyIiwicCIsInNsaWNlIiwiTnVtYmVyIiwicGFyc2VJbnQiLCJHRVQiLCJyZXF1ZXN0IiwiVVJMIiwidXJsIiwic3VwYWJhc2UiLCJxdWVyeSIsImZyb20iLCJzZWxlY3QiLCJvcmRlciIsImFzY2VuZGluZyIsImVxIiwiZGF0YSIsImVycm9yIiwiY29uc29sZSIsImxvZyIsIm1lc3NhZ2UiLCJqc29uIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./app/api/products/route.ts\n");

/***/ }),

/***/ "(rsc)/./lib/supabase/server.ts":
/*!********************************!*\
  !*** ./lib/supabase/server.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   createClient: () => (/* binding */ createClient)\n/* harmony export */ });\n/* harmony import */ var _supabase_ssr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @supabase/ssr */ \"(rsc)/./node_modules/@supabase/ssr/dist/module/index.js\");\n/* harmony import */ var next_headers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/headers */ \"(rsc)/./node_modules/next/dist/api/headers.js\");\n\n\nasync function createClient() {\n    const cookieStore = await (0,next_headers__WEBPACK_IMPORTED_MODULE_1__.cookies)();\n    return (0,_supabase_ssr__WEBPACK_IMPORTED_MODULE_0__.createServerClient)(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY, {\n        cookies: {\n            getAll () {\n                return cookieStore.getAll();\n            },\n            setAll (cookiesToSet) {\n                try {\n                    cookiesToSet.forEach(({ name, value, options })=>cookieStore.set(name, value, options));\n                } catch  {\n                // The `setAll` method was called from a Server Component.\n                // This can be ignored if you have middleware refreshing\n                // user sessions.\n                }\n            }\n        }\n    });\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9saWIvc3VwYWJhc2Uvc2VydmVyLnRzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFrRDtBQUNaO0FBRS9CLGVBQWVFO0lBQ3BCLE1BQU1DLGNBQWMsTUFBTUYscURBQU9BO0lBRWpDLE9BQU9ELGlFQUFrQkEsQ0FBQ0ksUUFBUUMsR0FBRyxDQUFDQyx3QkFBd0IsRUFBR0YsUUFBUUMsR0FBRyxDQUFDRSw2QkFBNkIsRUFBRztRQUMzR04sU0FBUztZQUNQTztnQkFDRSxPQUFPTCxZQUFZSyxNQUFNO1lBQzNCO1lBQ0FDLFFBQU9DLFlBQVk7Z0JBQ2pCLElBQUk7b0JBQ0ZBLGFBQWFDLE9BQU8sQ0FBQyxDQUFDLEVBQUVDLElBQUksRUFBRUMsS0FBSyxFQUFFQyxPQUFPLEVBQUUsR0FBS1gsWUFBWVksR0FBRyxDQUFDSCxNQUFNQyxPQUFPQztnQkFDbEYsRUFBRSxPQUFNO2dCQUNOLDBEQUEwRDtnQkFDMUQsd0RBQXdEO2dCQUN4RCxpQkFBaUI7Z0JBQ25CO1lBQ0Y7UUFDRjtJQUNGO0FBQ0YiLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcVGFsaGFcXERvd25sb2Fkc1xcdHJlbnRlY28td2Vic2l0ZXYzXFxsaWJcXHN1cGFiYXNlXFxzZXJ2ZXIudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlU2VydmVyQ2xpZW50IH0gZnJvbSBcIkBzdXBhYmFzZS9zc3JcIlxuaW1wb3J0IHsgY29va2llcyB9IGZyb20gXCJuZXh0L2hlYWRlcnNcIlxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlQ2xpZW50KCkge1xuICBjb25zdCBjb29raWVTdG9yZSA9IGF3YWl0IGNvb2tpZXMoKVxuXG4gIHJldHVybiBjcmVhdGVTZXJ2ZXJDbGllbnQocHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfU1VQQUJBU0VfVVJMISwgcHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfU1VQQUJBU0VfQU5PTl9LRVkhLCB7XG4gICAgY29va2llczoge1xuICAgICAgZ2V0QWxsKCkge1xuICAgICAgICByZXR1cm4gY29va2llU3RvcmUuZ2V0QWxsKClcbiAgICAgIH0sXG4gICAgICBzZXRBbGwoY29va2llc1RvU2V0KSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29va2llc1RvU2V0LmZvckVhY2goKHsgbmFtZSwgdmFsdWUsIG9wdGlvbnMgfSkgPT4gY29va2llU3RvcmUuc2V0KG5hbWUsIHZhbHVlLCBvcHRpb25zKSlcbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgLy8gVGhlIGBzZXRBbGxgIG1ldGhvZCB3YXMgY2FsbGVkIGZyb20gYSBTZXJ2ZXIgQ29tcG9uZW50LlxuICAgICAgICAgIC8vIFRoaXMgY2FuIGJlIGlnbm9yZWQgaWYgeW91IGhhdmUgbWlkZGxld2FyZSByZWZyZXNoaW5nXG4gICAgICAgICAgLy8gdXNlciBzZXNzaW9ucy5cbiAgICAgICAgfVxuICAgICAgfSxcbiAgICB9LFxuICB9KVxufVxuIl0sIm5hbWVzIjpbImNyZWF0ZVNlcnZlckNsaWVudCIsImNvb2tpZXMiLCJjcmVhdGVDbGllbnQiLCJjb29raWVTdG9yZSIsInByb2Nlc3MiLCJlbnYiLCJORVhUX1BVQkxJQ19TVVBBQkFTRV9VUkwiLCJORVhUX1BVQkxJQ19TVVBBQkFTRV9BTk9OX0tFWSIsImdldEFsbCIsInNldEFsbCIsImNvb2tpZXNUb1NldCIsImZvckVhY2giLCJuYW1lIiwidmFsdWUiLCJvcHRpb25zIiwic2V0Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./lib/supabase/server.ts\n");

/***/ }),

/***/ "(rsc)/./node_modules/@supabase/realtime-js/dist/main sync recursive":
/*!************************************************************!*\
  !*** ./node_modules/@supabase/realtime-js/dist/main/ sync ***!
  \************************************************************/
/***/ ((module) => {

function webpackEmptyContext(req) {
	var e = new Error("Cannot find module '" + req + "'");
	e.code = 'MODULE_NOT_FOUND';
	throw e;
}
webpackEmptyContext.keys = () => ([]);
webpackEmptyContext.resolve = webpackEmptyContext;
webpackEmptyContext.id = "(rsc)/./node_modules/@supabase/realtime-js/dist/main sync recursive";
module.exports = webpackEmptyContext;

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fproducts%2Froute&page=%2Fapi%2Fproducts%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fproducts%2Froute.ts&appDir=C%3A%5CUsers%5CTalha%5CDownloads%5Ctrenteco-websitev3%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CTalha%5CDownloads%5Ctrenteco-websitev3&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fproducts%2Froute&page=%2Fapi%2Fproducts%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fproducts%2Froute.ts&appDir=C%3A%5CUsers%5CTalha%5CDownloads%5Ctrenteco-websitev3%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CTalha%5CDownloads%5Ctrenteco-websitev3&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),\n/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/route-kind */ \"(rsc)/./node_modules/next/dist/server/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var C_Users_Talha_Downloads_trenteco_websitev3_app_api_products_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/api/products/route.ts */ \"(rsc)/./app/api/products/route.ts\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/products/route\",\n        pathname: \"/api/products\",\n        filename: \"route\",\n        bundlePath: \"app/api/products/route\"\n    },\n    resolvedPagePath: \"C:\\\\Users\\\\Talha\\\\Downloads\\\\trenteco-websitev3\\\\app\\\\api\\\\products\\\\route.ts\",\n    nextConfigOutput,\n    userland: C_Users_Talha_Downloads_trenteco_websitev3_app_api_products_route_ts__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        workAsyncStorage,\n        workUnitAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIvaW5kZXguanM/bmFtZT1hcHAlMkZhcGklMkZwcm9kdWN0cyUyRnJvdXRlJnBhZ2U9JTJGYXBpJTJGcHJvZHVjdHMlMkZyb3V0ZSZhcHBQYXRocz0mcGFnZVBhdGg9cHJpdmF0ZS1uZXh0LWFwcC1kaXIlMkZhcGklMkZwcm9kdWN0cyUyRnJvdXRlLnRzJmFwcERpcj1DJTNBJTVDVXNlcnMlNUNUYWxoYSU1Q0Rvd25sb2FkcyU1Q3RyZW50ZWNvLXdlYnNpdGV2MyU1Q2FwcCZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzJnJvb3REaXI9QyUzQSU1Q1VzZXJzJTVDVGFsaGElNUNEb3dubG9hZHMlNUN0cmVudGVjby13ZWJzaXRldjMmaXNEZXY9dHJ1ZSZ0c2NvbmZpZ1BhdGg9dHNjb25maWcuanNvbiZiYXNlUGF0aD0mYXNzZXRQcmVmaXg9Jm5leHRDb25maWdPdXRwdXQ9JnByZWZlcnJlZFJlZ2lvbj0mbWlkZGxld2FyZUNvbmZpZz1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQStGO0FBQ3ZDO0FBQ3FCO0FBQzZCO0FBQzFHO0FBQ0E7QUFDQTtBQUNBLHdCQUF3Qix5R0FBbUI7QUFDM0M7QUFDQSxjQUFjLGtFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxZQUFZO0FBQ1osQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLFFBQVEsc0RBQXNEO0FBQzlEO0FBQ0EsV0FBVyw0RUFBVztBQUN0QjtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQzBGOztBQUUxRiIsInNvdXJjZXMiOlsiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwcFJvdXRlUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9yb3V0ZS1tb2R1bGVzL2FwcC1yb3V0ZS9tb2R1bGUuY29tcGlsZWRcIjtcbmltcG9ydCB7IFJvdXRlS2luZCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL3JvdXRlLWtpbmRcIjtcbmltcG9ydCB7IHBhdGNoRmV0Y2ggYXMgX3BhdGNoRmV0Y2ggfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9saWIvcGF0Y2gtZmV0Y2hcIjtcbmltcG9ydCAqIGFzIHVzZXJsYW5kIGZyb20gXCJDOlxcXFxVc2Vyc1xcXFxUYWxoYVxcXFxEb3dubG9hZHNcXFxcdHJlbnRlY28td2Vic2l0ZXYzXFxcXGFwcFxcXFxhcGlcXFxccHJvZHVjdHNcXFxccm91dGUudHNcIjtcbi8vIFdlIGluamVjdCB0aGUgbmV4dENvbmZpZ091dHB1dCBoZXJlIHNvIHRoYXQgd2UgY2FuIHVzZSB0aGVtIGluIHRoZSByb3V0ZVxuLy8gbW9kdWxlLlxuY29uc3QgbmV4dENvbmZpZ091dHB1dCA9IFwiXCJcbmNvbnN0IHJvdXRlTW9kdWxlID0gbmV3IEFwcFJvdXRlUm91dGVNb2R1bGUoe1xuICAgIGRlZmluaXRpb246IHtcbiAgICAgICAga2luZDogUm91dGVLaW5kLkFQUF9ST1VURSxcbiAgICAgICAgcGFnZTogXCIvYXBpL3Byb2R1Y3RzL3JvdXRlXCIsXG4gICAgICAgIHBhdGhuYW1lOiBcIi9hcGkvcHJvZHVjdHNcIixcbiAgICAgICAgZmlsZW5hbWU6IFwicm91dGVcIixcbiAgICAgICAgYnVuZGxlUGF0aDogXCJhcHAvYXBpL3Byb2R1Y3RzL3JvdXRlXCJcbiAgICB9LFxuICAgIHJlc29sdmVkUGFnZVBhdGg6IFwiQzpcXFxcVXNlcnNcXFxcVGFsaGFcXFxcRG93bmxvYWRzXFxcXHRyZW50ZWNvLXdlYnNpdGV2M1xcXFxhcHBcXFxcYXBpXFxcXHByb2R1Y3RzXFxcXHJvdXRlLnRzXCIsXG4gICAgbmV4dENvbmZpZ091dHB1dCxcbiAgICB1c2VybGFuZFxufSk7XG4vLyBQdWxsIG91dCB0aGUgZXhwb3J0cyB0aGF0IHdlIG5lZWQgdG8gZXhwb3NlIGZyb20gdGhlIG1vZHVsZS4gVGhpcyBzaG91bGRcbi8vIGJlIGVsaW1pbmF0ZWQgd2hlbiB3ZSd2ZSBtb3ZlZCB0aGUgb3RoZXIgcm91dGVzIHRvIHRoZSBuZXcgZm9ybWF0LiBUaGVzZVxuLy8gYXJlIHVzZWQgdG8gaG9vayBpbnRvIHRoZSByb3V0ZS5cbmNvbnN0IHsgd29ya0FzeW5jU3RvcmFnZSwgd29ya1VuaXRBc3luY1N0b3JhZ2UsIHNlcnZlckhvb2tzIH0gPSByb3V0ZU1vZHVsZTtcbmZ1bmN0aW9uIHBhdGNoRmV0Y2goKSB7XG4gICAgcmV0dXJuIF9wYXRjaEZldGNoKHtcbiAgICAgICAgd29ya0FzeW5jU3RvcmFnZSxcbiAgICAgICAgd29ya1VuaXRBc3luY1N0b3JhZ2VcbiAgICB9KTtcbn1cbmV4cG9ydCB7IHJvdXRlTW9kdWxlLCB3b3JrQXN5bmNTdG9yYWdlLCB3b3JrVW5pdEFzeW5jU3RvcmFnZSwgc2VydmVySG9va3MsIHBhdGNoRmV0Y2gsICB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1hcHAtcm91dGUuanMubWFwIl0sIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fproducts%2Froute&page=%2Fapi%2Fproducts%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fproducts%2Froute.ts&appDir=C%3A%5CUsers%5CTalha%5CDownloads%5Ctrenteco-websitev3%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CTalha%5CDownloads%5Ctrenteco-websitev3&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app-render/after-task-async-storage.external":
/*!***********************************************************************************!*\
  !*** external "next/dist/server/app-render/after-task-async-storage.external.js" ***!
  \***********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ "../app-render/work-async-storage.external":
/*!*****************************************************************************!*\
  !*** external "next/dist/server/app-render/work-async-storage.external.js" ***!
  \*****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ "./work-unit-async-storage.external":
/*!**********************************************************************************!*\
  !*** external "next/dist/server/app-render/work-unit-async-storage.external.js" ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ "?32c4":
/*!****************************!*\
  !*** bufferutil (ignored) ***!
  \****************************/
/***/ (() => {

/* (ignored) */

/***/ }),

/***/ "?66e9":
/*!********************************!*\
  !*** utf-8-validate (ignored) ***!
  \********************************/
/***/ (() => {

/* (ignored) */

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ "http":
/*!***********************!*\
  !*** external "http" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ "https":
/*!************************!*\
  !*** external "https" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ "net":
/*!**********************!*\
  !*** external "net" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "punycode":
/*!***************************!*\
  !*** external "punycode" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("punycode");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "tls":
/*!**********************!*\
  !*** external "tls" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@supabase","vendor-chunks/ws","vendor-chunks/whatwg-url","vendor-chunks/tr46","vendor-chunks/webidl-conversions","vendor-chunks/cookie"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fproducts%2Froute&page=%2Fapi%2Fproducts%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fproducts%2Froute.ts&appDir=C%3A%5CUsers%5CTalha%5CDownloads%5Ctrenteco-websitev3%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CTalha%5CDownloads%5Ctrenteco-websitev3&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();